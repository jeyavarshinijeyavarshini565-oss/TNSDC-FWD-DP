const dots = document.querySelectorAll(".dot");
let pattern = [];
let correctPattern = [1, 2, 3]; // Correct unlock pattern = 123

dots.forEach(dot => {
  dot.addEventListener("click", () => {
    const id = parseInt(dot.getAttribute("data-id"));
    if (!pattern.includes(id)) {
      pattern.push(id);
      dot.classList.add("active");
    }

    // Check if full pattern entered
    if (pattern.length === correctPattern.length) {
      if (JSON.stringify(pattern) === JSON.stringify(correctPattern)) {
        alert("Unlocked ✅");
      } else {
        alert("Wrong Pattern ❌");
        resetPattern();
      }
    }
  });
});

function resetPattern() {
  pattern = [];
  dots.forEach(dot => dot.classList.remove("active"));
}